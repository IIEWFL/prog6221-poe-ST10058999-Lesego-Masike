﻿using System.Windows;

namespace CybersecurityChatbotGUI
{
    public partial class App : Application
    {
    }
}