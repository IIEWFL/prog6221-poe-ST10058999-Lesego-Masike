﻿using System; // Imports the System namespace for basic C# functionality like DateTime and string operations.
using System.Windows; // Imports the System.Windows namespace for WPF GUI components and Window class.
using Microsoft.VisualBasic; // Imports the Microsoft.VisualBasic namespace for Interaction.InputBox used in task and reminder input.

// References block containing documentation sources for the code.
/*
 * References:
 * 1. Microsoft Documentation - C# Programming Guide
 *    URL: https://learn.microsoft.com/en-us/dotnet/csharp/
 *    Description: Official documentation for C# namespaces, classes, and methods, including System, System.Media, System.Collections.Generic, and System.Windows for GUI development.
 * 2. GeekforGeeks - C# Programming Language
 *    URL: https://www.geeksforgeeks.org/c-sharp-programming-language/
 *    Description: Tutorials on C# classes, properties, collections, and event handling used in task management and quiz logic.
 * 3. Stack Overflow
 *    URL: https://stackoverflow.com/
 *    Description: Community-driven Q&A site where many C# programming issues are discussed, including error handling, debugging techniques, and GUI event handling.
 * 4. TutorialsPoint - C# Tutorial
 *    URL: https://www.tutorialspoint.com/csharp/
 *    Description: Guidance on file handling, console applications, and basic Windows Forms development in C#.
 * 5. Microsoft Documentation - XAML Overview
 *    URL: https://learn.microsoft.com/en-us/dotnet/desktop/wpf/xaml/
 *    Description: Official guide on XAML for creating graphical user interfaces, including Grid, StackPanel, and Button controls used in the MainWindow.xaml.
 * 6. Microsoft Documentation - DateTime and TimeSpan
 *    URL: https://learn.microsoft.com/en-us/dotnet/api/system.datetime
 *    Description: Documentation on DateTime and TimeSpan classes for managing timestamps and reminders in the activity log and task features.
 * 7. GeekforGeeks - C# List and Dictionary
 *    URL: https://www.geeksforgeeks.org/c-sharp-list-class/
 *    Description: Tutorials on using List and Dictionary collections for storing tasks, quiz questions, and activity logs.
 * 8. Microsoft Documentation - Event Handling in WPF
 *    URL: https://learn.microsoft.com/en-us/dotnet/desktop/wpf/events/
 *    Description: Guidance on handling button click events and updating UI elements like TextBox in the MainWindow.xaml.cs.
 * 9. Stack Overflow - Quiz Logic Implementation
 *    URL: https://stackoverflow.com/questions/tagged/c%23+quiz
 *    Description: Community solutions for implementing quiz logic, including score tracking and question sequencing.
 * 10. TutorialsPoint - C# Multithreading
 *    URL: https://www.tutorialspoint.com/csharp/csharp_multithreading.htm
 *    Description: Information on Thread.Sleep used in TypeResponse for animated text display.
 */

namespace CybersecurityChatbotGUI // Defines the namespace for the main window of the chatbot application.
{
    public partial class MainWindow : Window // Declares the MainWindow class, inheriting from Window for WPF GUI.
    {
        private Chatbot chatbot; // Declares a private field to hold the Chatbot instance.

        public MainWindow() // Constructor for the MainWindow class to initialize the window.
        {
            InitializeComponent(); // Calls the auto-generated method to initialize XAML components.
            chatbot = new Chatbot(); // Creates a new instance of the Chatbot class.
            chatbot.DisplayLogo(); // Calls the chatbot method to display the logo (console-based).
            chatbot.GreetUser(); // Calls the chatbot method to greet the user and set up initial interaction.
            UpdateChatDisplay("Hello! Welcome to the Cybersecurity Awareness Chatbot. Enter a topic, command, or type 'show activity log' to see your history."); // Displays initial welcome message in the chat area.
        }

        private void UpdateChatDisplay(string message) // Private method to update the chat display with a timestamped message.
        {
            ChatDisplay.Text += $"{DateTime.Now:HH:mm:ss} - {message}\n"; // Appends the current time and message to the ChatDisplay TextBox, adding a newline.
            ChatDisplay.ScrollToEnd(); // Scrolls the TextBox to the bottom to show the latest message.
        }

        private void SendButton_Click(object sender, RoutedEventArgs e) // Event handler for the Send button click event.
        {
            string input = UserInput.Text.Trim(); // Gets the text from the UserInput TextBox and removes leading/trailing whitespace.
            if (!string.IsNullOrEmpty(input)) // Checks if the input is not empty or null.
            {
                UpdateChatDisplay($"You: {input}"); // Displays the user's input in the chat area.
                if (chatbot.CurrentQuestionIndex < chatbot.QuizQuestions.Count && (input.ToUpper().StartsWith("A") || input.ToUpper().StartsWith("B") || input.ToUpper().StartsWith("C") || input.ToUpper().StartsWith("D") || input.ToUpper() == "TRUE" || input.ToUpper() == "FALSE")) // Checks if input is a quiz answer during an active quiz.
                {
                    string response = chatbot.CheckQuizAnswer(input); // Processes the quiz answer and gets the response.
                    UpdateChatDisplay($"Chatbot: {response}"); // Displays the chatbot's response to the quiz answer.
                }
                else // Handles non-quiz input.
                {
                    string response = chatbot.ProcessInput(input); // Processes the general input and gets the response.
                    UpdateChatDisplay($"Chatbot: {response}"); // Displays the chatbot's response.
                    if (response.Contains("Please enter task title and description")) // Checks if the response prompts for a task.
                    {
                        string taskInput = Interaction.InputBox("Enter task title and description (e.g., 'Enable two-factor authentication')", "Add Task"); // Opens an input box for task details.
                        if (!string.IsNullOrEmpty(taskInput)) // Checks if task input is provided.
                        {
                            chatbot.AddTask(taskInput, taskInput); // Adds the task using the input as both title and description.
                            UpdateChatDisplay($"Chatbot: Task added: {taskInput}. Would you like a reminder?"); // Confirms task addition and prompts for reminder.
                        }
                    }
                    else if (response.Contains("Enter reminder date")) // Checks if the response prompts for a reminder date.
                    {
                        var parts = input.Split(new[] { "remind me" }, StringSplitOptions.None)[1].Trim(); // Splits input to extract task title after "remind me".
                        var taskTitle = parts.Split(new[] { "to" }, StringSplitOptions.None).Last().Trim(); // Extracts the task title after "to".
                        string reminderInput = Interaction.InputBox($"Enter reminder date for '{taskTitle}' (e.g., 'in 3 days' or '2025-06-27')", "Set Reminder"); // Opens an input box for reminder date.
                        if (DateTime.TryParse(reminderInput, out DateTime reminder)) // Attempts to parse reminder as a DateTime.
                        {
                            chatbot.SetReminder(taskTitle, reminder); // Sets the reminder if parsing succeeds.
                            UpdateChatDisplay($"Chatbot: Reminder set for {taskTitle} on {reminder}."); // Confirms reminder setting.
                        }
                        else if (reminderInput.ToLower().Contains("in") && int.TryParse(reminderInput.Replace("in", "").Replace("days", "").Trim(), out int days)) // Checks for "in X days" format.
                        {
                            chatbot.SetReminder(taskTitle, DateTime.Now.AddDays(days)); // Sets reminder for X days from now.
                            UpdateChatDisplay($"Chatbot: Reminder set for {taskTitle} in {days} days."); // Confirms reminder setting.
                        }
                        else // Handles invalid date format.
                        {
                            UpdateChatDisplay($"Chatbot: Invalid date format for {taskTitle}."); // Notifies user of invalid format.
                        }
                    }
                }
                UserInput.Clear(); // Clears the UserInput TextBox after processing.
            }
        }

        private void AddTaskButton_Click(object sender, RoutedEventArgs e) // Event handler for the AddTask button click event.
        {
            string taskInput = Interaction.InputBox("Enter task title and description (e.g., 'Enable two-factor authentication')", "Add Task"); // Opens an input box for task details.
            if (!string.IsNullOrEmpty(taskInput)) // Checks if task input is provided.
            {
                chatbot.AddTask(taskInput, taskInput); // Adds the task using the input as both title and description.
                UpdateChatDisplay($"Chatbot: Task added: {taskInput}. Would you like a reminder?"); // Confirms task addition and prompts for reminder.
            }
        }

        private void SetReminderButton_Click(object sender, RoutedEventArgs e) // Event handler for the SetReminder button click event.
        {
            string taskTitle = Interaction.InputBox("Enter task title to set reminder", "Set Reminder"); // Opens an input box for task title.
            if (!string.IsNullOrEmpty(taskTitle)) // Checks if task title is provided.
            {
                string reminderInput = Interaction.InputBox($"Enter reminder date for '{taskTitle}' (e.g., 'in 3 days' or '2025-06-27')", "Set Reminder"); // Opens an input box for reminder date.
                if (DateTime.TryParse(reminderInput, out DateTime reminder)) // Attempts to parse reminder as a DateTime.
                {
                    chatbot.SetReminder(taskTitle, reminder); // Sets the reminder if parsing succeeds.
                    UpdateChatDisplay($"Chatbot: Reminder set for {taskTitle} on {reminder}."); // Confirms reminder setting.
                }
                else if (reminderInput.ToLower().Contains("in") && int.TryParse(reminderInput.Replace("in", "").Replace("days", "").Trim(), out int days)) // Checks for "in X days" format.
                {
                    chatbot.SetReminder(taskTitle, DateTime.Now.AddDays(days)); // Sets reminder for X days from now.
                    UpdateChatDisplay($"Chatbot: Reminder set for {taskTitle} in {days} days."); // Confirms reminder setting.
                }
                else // Handles invalid date format.
                {
                    UpdateChatDisplay($"Chatbot: Invalid date format for {taskTitle}."); // Notifies user of invalid format.
                }
            }
        }

        private void StartQuizButton_Click(object sender, RoutedEventArgs e) // Event handler for the StartQuiz button click event.
        {
            string response = chatbot.ProcessInput("start quiz"); // Processes the "start quiz" command.
            UpdateChatDisplay($"Chatbot: {response}"); // Displays the chatbot's response to starting the quiz.
            if (response.Contains("Quiz started!")) // Checks if the quiz started successfully.
            {
                string firstQuestion = chatbot.ProcessInput("next question"); // Gets the first quiz question.
                UpdateChatDisplay($"Chatbot: {firstQuestion}"); // Displays the first question.
            }
        }

        private void ShowLogButton_Click(object sender, RoutedEventArgs e) // Event handler for the ShowLog button click event.
        {
            string log = chatbot.ProcessInput("show activity log"); // Processes the "show activity log" command.
            UpdateChatDisplay($"Chatbot: {log}"); // Displays the activity log.
        }
    }
}