﻿using System; // Imports the System namespace for basic C# functionality like strings, exceptions, and DateTime.
using System.Collections.Generic; // Imports the System.Collections.Generic namespace for generic collections like List and Dictionary.
using System.Linq; // Imports the System.Linq namespace for LINQ operations like Select and Take.
using System.Media; // Imports the System.Media namespace for audio playback using SoundPlayer.
using System.Threading; // Imports the System.Threading namespace for Thread.Sleep used in text animation.

// References block containing documentation sources for the code.
/*
 * References:
 * 1. Microsoft Documentation - C# Programming Guide
 *    URL: https://learn.microsoft.com/en-us/dotnet/csharp/
 *    Description: Official documentation for C# namespaces, classes, and methods, including System, System.Media, System.Collections.Generic, and System.Windows for GUI development.
 * 2. GeekforGeeks - C# Programming Language
 *    URL: https://www.geeksforgeeks.org/c-sharp-programming-language/
 *    Description: Tutorials on C# classes, properties, collections, and event handling used in task management and quiz logic.
 * 3. Stack Overflow
 *    URL: https://stackoverflow.com/
 *    Description: Community-driven Q&A site where many C# programming issues are discussed, including error handling, debugging techniques, and GUI event handling.
 * 4. TutorialsPoint - C# Tutorial
 *    URL: https://www.tutorialspoint.com/csharp/
 *    Description: Guidance on file handling, console applications, and basic Windows Forms development in C#.
 * 5. Microsoft Documentation - XAML Overview
 *    URL: https://learn.microsoft.com/en-us/dotnet/desktop/wpf/xaml/
 *    Description: Official guide on XAML for creating graphical user interfaces, including Grid, StackPanel, and Button controls used in the MainWindow.xaml.
 * 6. Microsoft Documentation - DateTime and TimeSpan
 *    URL: https://learn.microsoft.com/en-us/dotnet/api/system.datetime
 *    Description: Documentation on DateTime and TimeSpan classes for managing timestamps and reminders in the activity log and task features.
 * 7. GeekforGeeks - C# List and Dictionary
 *    URL: https://www.geeksforgeeks.org/c-sharp-list-class/
 *    Description: Tutorials on using List and Dictionary collections for storing tasks, quiz questions, and activity logs.
 * 8. Microsoft Documentation - Event Handling in WPF
 *    URL: https://learn.microsoft.com/en-us/dotnet/desktop/wpf/events/
 *    Description: Guidance on handling button click events and updating UI elements like TextBox in the MainWindow.xaml.cs.
 * 9. Stack Overflow - Quiz Logic Implementation
 *    URL: https://stackoverflow.com/questions/tagged/c%23+quiz
 *    Description: Community solutions for implementing quiz logic, including score tracking and question sequencing.
 * 10. TutorialsPoint - C# Multithreading
 *    URL: https://www.tutorialspoint.com/csharp/csharp_multithreading.htm
 *    Description: Information on Thread.Sleep used in TypeResponse for animated text display.
 */

namespace CybersecurityChatbotGUI // Defines the namespace for the chatbot application.
{
    public class Chatbot // Declares the Chatbot class to encapsulate chatbot functionality.
    {
        public string UserName { get; set; } // Public property to store the user's name, accessible and modifiable.
        public string FavoriteTopic { get; set; } // Public property to store the user's favorite cybersecurity topic.
        public string LastTopic { get; set; } // Public property to store the last discussed topic for context.
        private Random RandomGenerator { get; set; } // Private property to generate random responses, initialized later.
        private Dictionary<string, string[]> Responses { get; set; } = new Dictionary<string, string[]>(); // Private dictionary to store predefined responses, initialized with a new instance.
        public List<(string Action, DateTime Timestamp)> ActivityLog { get; set; } = new List<(string, DateTime)>(); // Public list to log all actions with timestamps.
        public List<(string Title, string Description, DateTime? Reminder)> Tasks { get; set; } = new List<(string, string, DateTime?)>(); // Public list to store tasks with titles, descriptions, and optional reminders.
        public int QuizScore { get; set; } // Public property to track the user's quiz score.
        public List<string> QuizQuestions { get; set; } = new List<string>(); // Public list to store quiz questions.
        public int CurrentQuestionIndex { get; set; } // Public property to track the current quiz question index.

        public Chatbot() // Constructor for the Chatbot class to initialize default values.
        {
            UserName = "User"; // Sets default username.
            FavoriteTopic = ""; // Initializes favorite topic as empty.
            LastTopic = ""; // Initializes last topic as empty.
            RandomGenerator = new Random(); // Initializes the random number generator.
            InitializeResponses(); // Calls method to set up response dictionary.
            InitializeQuiz(); // Calls method to set up quiz questions.
            ActivityLog = new List<(string, DateTime)>(); // Initializes activity log list.
            Tasks = new List<(string, string, DateTime?)>(); // Initializes tasks list.
            QuizScore = 0; // Initializes quiz score to zero.
            CurrentQuestionIndex = 0; // Initializes current question index to zero.
        }

        private void InitializeResponses() // Private method to populate the Responses dictionary.
        {
            Responses = new Dictionary<string, string[]> // Assigns a new dictionary instance.
            {
                { "password", new[] { "Make sure to use strong, unique passwords...", "A strong password should be more than 8 characters long", "Consider using a password manager..." } }, // Adds password-related responses.
                { "scam", new[] { "Be cautious of emails asking about personal information", "Scammers can be very convincing, so always be alert", "If something seems too good to be true then they most likely are scammers" } }, // Adds scam-related responses.
                { "privacy", new[] { "It’s crucial to stay safe online...", "Protect your privacy by using...", "Privacy is key! Avoid sharing personal information" } }, // Adds privacy-related responses.
                { "default", new[] { "I’m not sure I understand please rephrase in another way", "I didn’t catch that", "Hmm, I’m not sure about that..." } } // Adds default responses for unrecognized input.
            };
        }

        private void InitializeQuiz() // Private method to populate the QuizQuestions list.
        {
            QuizQuestions = new List<string> // Assigns a new list instance.
            {
                "What should you do if you receive an email asking for your password? A) Reply B) Delete C) Report as phishing D) Ignore", // Adds first quiz question.
                "True or False: Reusing passwords across sites is safe.", // Adds second quiz question.
                "What is a key feature of a strong password? A) Short length B) Special characters C) Personal info D) All the same letter", // Adds third quiz question.
                "True or False: Public Wi-Fi is always secure to use.", // Adds fourth quiz question.
                "What should you do if you suspect a phishing call? A) Share info B) Hang up C) Call back D) Ignore", // Adds fifth quiz question.
                "True or False: Updating software helps protect against threats.", // Adds sixth quiz question.
                "What is social engineering? A) Hacking B) Phishing C) Coding D) Networking", // Adds seventh quiz question.
                "True or False: Two-factor authentication adds security.", // Adds eighth quiz question.
                "What is a safe browsing habit? A) Click all links B) Use HTTPS C) Share passwords D) Disable updates", // Adds ninth quiz question.
                "True or False: Backing up data prevents loss from ransomware." // Adds tenth quiz question.
            };
        }

        public string DetectSentiment(string input) // Public method to detect the sentiment of user input.
        {
            input = input.ToLower(); // Converts input to lowercase for case-insensitive matching.
            if (input.Contains("worried") || input.Contains("scared")) return "worried"; // Returns "worried" if input contains worried or scared.
            if (input.Contains("curious") || input.Contains("wondering")) return "curious"; // Returns "curious" if input contains curious or wondering.
            if (input.Contains("frustrated") || input.Contains("annoyed")) return "frustrated"; // Returns "frustrated" if input contains frustrated or annoyed.
            return "neutral"; // Returns "neutral" if no specific sentiment is detected.
        }

        public string AdjustResponseForSentiment(string response, string sentiment) // Public method to adjust response based on sentiment.
        {
            return sentiment switch // Uses switch expression to handle different sentiments.
            {
                "worried" => "I understand your concern. " + response + " Let me share some tips to help you stay safe.", // Adds empathetic message for worried sentiment.
                "curious" => "That’s a great question! " + response + " Want to know more?", // Adds encouraging message for curious sentiment.
                "frustrated" => "I’m sorry you’re feeling that way. " + response + " Let’s work through this together.", // Adds supportive message for frustrated sentiment.
                _ => response // Returns original response for neutral or unknown sentiment.
            };
        }

        public string ProcessInput(string input) // Public method to process user input and generate a response.
        {
            input = input.ToLower().Trim(); // Converts input to lowercase and removes leading/trailing whitespace.
            string sentiment = DetectSentiment(input); // Detects the sentiment of the input.
            string response; // Declares variable to hold the response.
            string topic = LastTopic; // Initializes topic with the last discussed topic.

            // Activity Log Command
            if (input == "show activity log" || input == "what have you done for me?") // Checks for activity log command.
            {
                return string.Join("\n", ActivityLog.Take(10).Select((a, i) => $"{i + 1}. {a.Action} (at {a.Timestamp})")); // Returns formatted list of last 10 activities.
            }
            // Task and Reminder Commands
            else if (input.Contains("add task") || input.Contains("set task") || input.Contains("create task")) // Checks for task addition command.
            {
                return "Please enter task title and description (e.g., 'Enable two-factor authentication')."; // Prompts for task details.
            }
            else if (input.Contains("remind me") && (input.Contains("task") || input.Contains("to"))) // Checks for reminder command.
            {
                var parts = input.Split(new[] { "remind me" }, StringSplitOptions.None)[1].Trim(); // Splits input to extract task title.
                var taskTitle = parts.Split(new[] { "to" }, StringSplitOptions.None).Last().Trim(); // Extracts the task title after "to".
                return $"Enter reminder date for '{taskTitle}' (e.g., 'in 3 days' or '2025-06-27')."; // Prompts for reminder date.
            }
            // Quiz Commands
            else if (input == "start quiz") // Checks for quiz start command.
            {
                QuizScore = 0; // Resets quiz score.
                CurrentQuestionIndex = 0; // Resets current question index.
                ActivityLog.Add(("Quiz started", DateTime.Now)); // Logs quiz start with current timestamp.
                return "Quiz started! Get ready to test your cybersecurity knowledge."; // Returns quiz start message.
            }
            else if (input == "next question" && CurrentQuestionIndex < QuizQuestions.Count) // Checks for next question command.
            {
                return QuizQuestions[CurrentQuestionIndex]; // Returns the current quiz question.
            }
            else if (input == "end quiz") // Checks for quiz end command.
            {
                string feedback = QuizScore >= QuizQuestions.Count / 2 ? "Great job! You’re a cybersecurity pro!" : "Keep learning to stay safe online!"; // Determines feedback based on score.
                ActivityLog.Add(("Quiz completed with score " + QuizScore, DateTime.Now)); // Logs quiz completion with score.
                return $"Quiz ended! Your score: {QuizScore}/{QuizQuestions.Count}\n{feedback}"; // Returns quiz end message with score and feedback.
            }

            // Keyword Detection for Topics
            if (input.Contains("password")) topic = "password"; // Sets topic to "password" if input contains it.
            else if (input.Contains("scam") || input.Contains("phishing")) topic = "scam"; // Sets topic to "scam" if input contains scam or phishing.
            else if (input.Contains("privacy")) topic = "privacy"; // Sets topic to "privacy" if input contains it.
            else if (LastTopic != "" && (input.Contains("more") || input.Contains("continue"))) topic = LastTopic; // Continues last topic if "more" or "continue" is detected.
            else topic = "default"; // Sets topic to "default" if no specific topic is detected.

            LastTopic = topic == "default" ? LastTopic : topic; // Updates LastTopic, retaining previous if default.
            response = Responses[topic][RandomGenerator.Next(Responses[topic].Length)]; // Selects a random response for the topic.
            if (FavoriteTopic == topic && !string.IsNullOrEmpty(FavoriteTopic)) // Checks if topic matches favorite topic.
                response = $"{UserName}, since you’re interested in {FavoriteTopic}, here’s a tip: " + response; // Adds personalized tip if topic matches favorite.
            response = AdjustResponseForSentiment(response, sentiment); // Adjusts response based on sentiment.
            ActivityLog.Add(("Response given on " + topic, DateTime.Now)); // Logs the response action with timestamp.
            return response; // Returns the final response.
        }

        public void AddTask(string title, string description, DateTime? reminder = null) // Public method to add a task with optional reminder.
        {
            if (string.IsNullOrWhiteSpace(title)) return; // Exits if title is null or whitespace.
            Tasks.Add((title, description, reminder)); // Adds task to the tasks list.
            ActivityLog.Add(("Task added: " + title + (reminder.HasValue ? $" (Reminder: {reminder.Value})" : ""), DateTime.Now)); // Logs task addition with reminder if present.
        }

        public void SetReminder(string title, DateTime reminder) // Public method to set a reminder for a task.
        {
            if (string.IsNullOrWhiteSpace(title)) return; // Exits if title is null or whitespace.
            var task = Tasks.Find(t => t.Title == title); // Finds the task by title.
            if (task != default) task.Item3 = reminder; // Updates reminder if task is found.
            ActivityLog.Add(("Reminder set for " + title + $" (at {reminder})", DateTime.Now)); // Logs reminder setting with timestamp.
        }

        public string CheckQuizAnswer(string answer) // Public method to check quiz answer and provide feedback.
        {
            if (CurrentQuestionIndex >= QuizQuestions.Count) return "Quiz has ended."; // Returns message if quiz is over.
            string question = QuizQuestions[CurrentQuestionIndex]; // Gets the current question.
            bool correct = false; // Initializes correct flag.
            string feedback = ""; // Initializes feedback string.

            if (question.Contains("phishing") && answer.ToUpper() == "C") { correct = true; feedback = "Correct! Reporting phishing emails helps prevent scams."; } // Checks phishing question.
            else if (question.Contains("Reusing") && answer.ToUpper() == "FALSE") { correct = true; feedback = "Correct! Reusing passwords is unsafe."; } // Checks reusing passwords question.
            else if (question.Contains("strong password") && answer.ToUpper() == "B") { correct = true; feedback = "Correct! Special characters strengthen passwords."; } // Checks strong password question.
            else if (question.Contains("Public Wi-Fi") && answer.ToUpper() == "FALSE") { correct = true; feedback = "Correct! Public Wi-Fi is not always secure."; } // Checks public Wi-Fi question.
            else if (question.Contains("phishing call") && answer.ToUpper() == "B") { correct = true; feedback = "Correct! Hanging up prevents phishing risks."; } // Checks phishing call question.
            else if (question.Contains("Updating software") && answer.ToUpper() == "TRUE") { correct = true; feedback = "Correct! Updates protect against threats."; } // Checks software update question.
            else if (question.Contains("social engineering") && answer.ToUpper() == "B") { correct = true; feedback = "Correct! Phishing is a form of social engineering."; } // Checks social engineering question.
            else if (question.Contains("Two-factor authentication") && answer.ToUpper() == "TRUE") { correct = true; feedback = "Correct! Two-factor adds security."; } // Checks two-factor authentication question.
            else if (question.Contains("safe browsing habit") && answer.ToUpper() == "B") { correct = true; feedback = "Correct! Using HTTPS is a safe habit."; } // Checks safe browsing question.
            else if (question.Contains("Backing up data") && answer.ToUpper() == "TRUE") { correct = true; feedback = "Correct! Backups prevent ransomware loss."; } // Checks backup question.
            else feedback = "Wrong! Let’s review: " + (question.Contains("phishing") ? "Report phishing emails." : question.Contains("Reusing") ? "Don’t reuse passwords." : question.Contains("Public Wi-Fi") ? "Avoid public Wi-Fi without security." : question.Contains("phishing call") ? "Hang up on suspicious calls." : question.Contains("Updating software") ? "Keep software updated." : question.Contains("social engineering") ? "Phishing is social engineering." : question.Contains("Two-factor authentication") ? "Use two-factor authentication." : question.Contains("safe browsing habit") ? "Use HTTPS." : "Backup your data."); // Sets feedback for incorrect answers.

            if (correct) QuizScore++; // Increments score if answer is correct.
            CurrentQuestionIndex++; // Moves to next question.
            ActivityLog.Add(("Quiz question " + CurrentQuestionIndex + " answered: " + answer, DateTime.Now)); // Logs answer with timestamp.
            return (correct ? "Correct!" : "Wrong!") + " " + feedback + (CurrentQuestionIndex < QuizQuestions.Count ? "\nNext question? Type 'next question'." : "\nQuiz ended!"); // Returns feedback with prompt or end message.
        }

        public void PlayWelcomeAudio() // Public method to play welcome audio.
        {
            try // Begins try block for error handling.
            {
                string audioFile = "welcome.wav"; // Defines the audio file name.
                string fullPath = System.IO.Path.GetFullPath(audioFile); // Gets the full path of the audio file.
                Console.WriteLine($"Attempting to play: {fullPath}"); // Logs the attempt to play audio.

                if (!System.IO.File.Exists(audioFile)) // Checks if the audio file exists.
                {
                    Console.WriteLine($"Error: {audioFile} not found in the application directory."); // Logs error if file is missing.
                    return; // Exits method if file is not found.
                }
                SoundPlayer player = new SoundPlayer(audioFile); // Creates a new SoundPlayer instance.
                player.Play(); // Plays the audio file.
                Console.WriteLine("Audio playback started."); // Logs successful playback start.
            }
            catch (Exception ex) // Catches any exceptions during audio playback.
            {
                Console.WriteLine($"Error playing audio: {ex.Message}\nStack Trace: {ex.StackTrace}"); // Logs the error message and stack trace.
            }
        }

        public void DisplayLogo() // Public method to display the chatbot logo.
        {
            try // Begins try block for error handling.
            {
                Console.WriteLine("Displaying logo."); // Logs the start of logo display.
                Console.ForegroundColor = ConsoleColor.Cyan; // Sets console text color to cyan.
                string logo = @"
       ==============================
             Cybersecurity Bot
        ==============================
          ___          _ _       
         | _ \__ _ _ _| | | ___  
         |  _/ _` | '_| | |/ _ \ 
         |_| \__,_|_| |_|_|\___/
        =============================="; // Defines the ASCII art logo.
                TypeResponse(logo); // Displays the logo with animation.
                Console.WriteLine("Logo displayed."); // Logs completion of logo display.
            }
            catch (Exception ex) // Catches any exceptions during logo display.
            {
                Console.WriteLine($"Error showing logo: {ex.Message}"); // Logs the error message.
            }
        }

        public void TypeResponse(string message) // Public method to display text with animation.
        {
            try // Begins try block for error handling.
            {
                Console.ForegroundColor = ConsoleColor.Yellow; // Sets console text color to yellow.
                foreach (char c in message) // Iterates over each character in the message.
                {
                    Console.Write(c); // Writes the current character.
                    Thread.Sleep(50); // Pauses for 50ms to create animation effect.
                }
                Console.WriteLine(); // Moves to a new line after message.
                Console.ResetColor(); // Resets console color to default.
            }
            catch (Exception ex) // Catches any exceptions during text display.
            {
                Console.WriteLine($"Error in TypeResponse: {ex.Message}"); // Logs the error message.
            }
        }

        public void GreetUser() // Public method to greet the user and set up initial interaction.
        {
            try // Begins try block for error handling.
            {
                Console.WriteLine("Starting GreetUser."); // Logs the start of the greeting process.
                Console.WriteLine(new string('-', 50)); // Prints a line of 50 hyphens as a separator.
                TypeResponse("Please enter your name:"); // Prompts user for name with animation.
                string inputName = Console.ReadLine(); // Reads the user's name input.
                UserName = string.IsNullOrWhiteSpace(inputName) ? "User" : inputName.Trim(); // Sets username, defaults to "User" if input is empty or whitespace.

                Console.ForegroundColor = ConsoleColor.Green; // Sets console text color to green.
                string welcomeMessage = $"Hello, {UserName}! Welcome to the Cybersecurity Awareness Bot!"; // Constructs welcome message.
                Console.WriteLine("Starting welcome message."); // Logs the start of welcome message.
                PlayWelcomeAudio(); // Plays welcome audio.
                TypeResponse(welcomeMessage); // Displays welcome message with animation.
                Console.WriteLine("Welcome message completed."); // Logs completion of welcome message.
                TypeResponse("I'm here to help you learn about staying safe online."); // Displays help message.
                TypeResponse("What’s your favorite cybersecurity topic? (e.g., password, scam, privacy)"); // Prompts for favorite topic.
                string inputTopic = Console.ReadLine(); // Reads the user's topic input.
                FavoriteTopic = string.IsNullOrWhiteSpace(inputTopic) ? "" : inputTopic.ToLower().Trim(); // Sets favorite topic, defaults to empty if invalid.
                if (Responses.ContainsKey(FavoriteTopic)) // Checks if the topic is valid.
                {
                    TypeResponse($"Great choice, {UserName}! I’ll keep that in mind. Let’s talk about {FavoriteTopic} or anything else!"); // Confirms topic choice.
                }
                Console.WriteLine("GreetUser completed."); // Logs completion of greeting process.
            }
            catch (Exception ex) // Catches any exceptions during greeting.
            {
                Console.WriteLine($"Error in GreetUser: {ex.Message}\nStack Trace: {ex.StackTrace}"); // Logs the error message and stack trace.
            }
        }
    }
}